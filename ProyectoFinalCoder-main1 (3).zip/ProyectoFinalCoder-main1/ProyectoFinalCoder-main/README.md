# ProyectoFinalCoder

Ingresando a la página de inicio '127.0.0.1:800/AppCoder/' nos encontramos con una barra de navegación que nos permite movernos por distintos paneles, encontrando diferentes funcionalidades.

1. Equipos:
    Podremos ingresar a la base de datos de equipos ingresando el nombre y el director técnico que le corresponde.

2. Jugadores:
    Al igual que los equipos, podremos cargar jugadores por nombre y el equipo al que representan.

3. Búsqueda:
    En esta pantalla podremos hacer una búsqueda de jugadores, si el jugador buscado está registrado en las bases nos mostrará su nombre completo y el club en el que juega.



*** Tener en cuenta que planeo modificar el front para mejorar la visual, y a su vez agregar un nuevo Model que sea 'Partidos' para comenzar a hacer un registro de partidos y resultados entre equipos ***

Hecho POR ivanrivasgr


